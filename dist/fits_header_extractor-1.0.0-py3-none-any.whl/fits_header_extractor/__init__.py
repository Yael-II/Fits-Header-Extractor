"""
FITS header extractor is a python library to extract the header of FITS.
@ Author: Moussouni, Yaël (MSc student)
@ Institution:  Université de Strasbourg, CNRS, Observatoire astronomique
                de Strasbourg, UMR 7550, F-67000 Strasbourg, France
@ Date: 2024-12-31
@ Licence: GNU General Public License v3.0
"""
